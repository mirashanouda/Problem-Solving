#include <bits/stdc++.h>
using namespace std; 
typedef long long ll;

void solution(){
    
}

int main(){
    int tc = 1; //cin >> tc;
    while (cin >> tc) solution();
    return 0; 
}
