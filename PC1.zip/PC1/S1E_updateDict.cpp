#include <bits/stdc++.h>
using namespace std; 
typedef long long ll;

void solution(){
    map<string, int> old, nw;
    string old_dic, new_dic, line;
    // int tt = 2;
    // while (tt--){
    //     getline(cin, line, ',');
    //     line.erase(0,1); //remove the first {
    //     line.erase(line.size() - 1); //remove the last }
    //     cout << line << "\n";
    // }
    getline(cin, old_dic, ',');
    getline(cin, new_dic, ',');
    old_dic.erase(0,1); //remove the first {
    old_dic.erase(old_dic.size() - 1); //remove the last }
    new_dic.erase(0,1); //remove the first {
    new_dic.erase(new_dic.size() - 1); //remove the last }

    cout << old_dic << " " << new_dic << "\n";
    // //empty dic
    // string k = "";
    // string v = "";
    // for (int i = 1; i < (int)old_dic.size() - 1; ++i){
    //     k = "";
    //     v = "";
    //     while (old_dic[i] != ':'){
    //         k += old_dic[i];
    //     }
    //     while (old_dic[i] != ','){
    //         v += old_dic[i];
    //     }
    //     old_dic[k] = stoi(v);
    // }
}

int main(){
    int tc = 1; //cin >> tc;
    while (tc--) {
        solution();
    }
    return 0; 
}

