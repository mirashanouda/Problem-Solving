//https://onlinejudge.org/index.php?option=com_onlinejudge&Itemid=8&page=show_problem&problem=1756
#include <bits/stdc++.h>
using namespace std;

void solution(string text){
    set<string> dic;
    string word = "";
    for (auto c : text){
        if (isalpha(c)) word += tolower(c);
        else if (!word.empty()) {
            dic.insert(word);
            word = "";
        }
    }
    for (auto it = dic.begin(); it != dic.end(); it++)
        cout << *it << "\n";
}

int main(){
    string line, text = "";
    while (getline(cin, line)){
        text += (line + " ");
    }
    // cout << text << "\n";
    solution(text);
    return 0;
}