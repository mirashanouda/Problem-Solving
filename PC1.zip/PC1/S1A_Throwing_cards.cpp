/*
Given is an ordered deck of n cards numbered 1 to n with card 1 at the top and card n at the
bottom. The following operation is performed as long as there are at least two cards in the deck:
Throw away the top card and move the card that is now on the top of the
deck to the bottom of the deck.
Your task is to find the sequence of discarded
cards and the last, remaining card.

Input
Each line of input (except the last) contains a
number n ≤ 50. The last line contains ‘0’ and
this line should not be processed.

Output
For each number from the input produce two
lines of output. The first line presents the sequence of discarded cards, the second line 
reports the last remaining card. No line will have leading or trailing spaces.
*/
#include <bits/stdc++.h>
using namespace std;

void solution(vector<int> tc){
    for (int i = 0; i < tc.size(); i++){
        if (tc[i] == 1){
            // cout << "Discarded cards:" << endl;
            // cout << "Remaining card:" << endl;
            // break;
            continue;
        }
        queue<string> seq;
        for (int j = 2; j <= tc[i]; j++)
            seq.push(to_string(j));
        
        string discarded = "1", 
            remaining, 
            send_back, 
            throw_away;
        while(seq.size() > 1){
            //get the fist element back
            send_back = seq.front();
            seq.push(send_back);
            seq.pop();
            throw_away = seq.front();
            discarded += (", " + throw_away);
            seq.pop();
        }
        remaining = seq.front();
        seq.pop();
        cout << "Discarded cards: " << discarded << endl;
        cout << "Remaining card: " << remaining << endl;
    }
}

int main(){
    vector<int> tc;
    int input;
    while (cin >> input){
        if (input)
            tc.push_back(input);
        else break;
    }
    solution(tc);
    return 0;
}