#include <bits/stdc++.h>
using namespace std; 
typedef long long ll;

vector<pair<int, int>> in; 
string output = "";

bool isQueue(){
    int out;
    queue<int> q;
    for (auto i : in){
        if (i.first == 1) q.push(i.second);
        else {
            out = q.front();
            q.pop();
            if (out == i.second) continue;
            else return false;
        }
    }
    return true;
}

bool isStack(){
    int out;
    stack<int> s;
    for (auto i : in){
        if (i.first == 1) s.push(i.second);
        else {
            out = s.top(); 
            s.pop();
            if (out == i.second) continue;
            else return false;
        }
    }
    return true;
}

bool isPriority(){
    int out;
    priority_queue<int> pq;
    for (auto i : in){
        if (i.first == 1) pq.push(i.second);
        else {
            out = pq.top(); 
            pq.pop();
            if (out == i.second) continue;
            else return false;
        }
    }
    return true;
}

string solution(){
    for (int i = 0; i < (int)in.size(); i++) cin >> in[i].first >> in[i].second;
    // start solution:
    if (!isStack() && !isQueue() && !isPriority()) return "impossible\n";
    else if (isStack() && !isQueue() && !isPriority()) return "stack\n";
    else if (!isStack() && isQueue() && !isPriority()) return "queue\n";
    else if (!isStack() && !isQueue() && isPriority()) return "priority queue\n";
    else return "not sure\n";
}

int main(){
    int tc; //cin >> tc;
    while (cin >> tc) {
        in.resize(tc);
        fill(in.begin(), in.end(), make_pair(0, 0));
        output += solution();
    }
    cout << output;
    return 0; 
}
