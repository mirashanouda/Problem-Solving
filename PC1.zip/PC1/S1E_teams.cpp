#include <bits/stdc++.h>
using namespace std; 
typedef long long ll;

void solution(){
    int n;
    cin >> n;
    vector<int> cld(n);
    for(int i = 0; i < n; i++) cin >> cld[i]++;
    for(int i = 0; i < n; i++) cout << cld[i] << "\n";

    return;
    //map of vectors of indexes of the apearance
    //
    
}

int main(){
    int tc = 1; //cin >> tc;
    while (tc--) solution();
    return 0; 
}
