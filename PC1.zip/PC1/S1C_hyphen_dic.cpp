//https://onlinejudge.org/index.php?option=onlinejudge&Itemid=8&page=show_problem&problem=2003
#include <bits/stdc++.h>
using namespace std;

void solution(string text){
    set<string> dic;
    string word = "";
    for (auto c : text){
        if (isalpha(c) || c == '-') word += tolower(c);
        else if (!word.empty()) {
            dic.insert(word);
            word = "";
        }
    }
    for (auto it = dic.begin(); it != dic.end(); it++)
        cout << *it << "\n";
}

int main(){
    string line, text = "";
    while (getline(cin, line)){
        if (line[line.size() - 1] == '-'){
            line.pop_back();
            text += line;
        }
        else 
            text += (line + " ");
    }
    // cout << text << "\n";
    solution(text);
    return 0;
}